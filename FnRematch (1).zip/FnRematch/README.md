# Fortnite Rematch (Android)

Erkennt das Rundenende per Farbvergleich auf dem Bildschirm, tippt automatisch "Nächste Runde" und bewegt den Spieler zwischendurch zufällig (optional), damit direkt die nächste Runde mit einem anderen Team startet.

Voraussetzung: Android 11 oder neuer.

## 1. APK bauen

**Weg A: ohne PC, nur im Browser (GitHub)**
1. Kostenloses Konto auf github.com anlegen und ein neues Repository erstellen.
2. Den kompletten Inhalt dieses Ordners hochladen (auch den versteckten Ordner `.github`).
3. Im Repository auf **Actions** gehen und den Lauf "APK bauen" abwarten (ca. 3-5 Min).
4. Im fertigen Lauf unten unter **Artifacts** die Datei `FortniteRematch-APK` herunterladen, entpacken, `app-debug.apk` installieren.

**Weg B: Android Studio am PC**
Ordner öffnen, warten bis Gradle fertig ist, dann **Build > Build APK(s)**.

## 2. Installieren und einrichten

1. APK installieren (Browser/Dateimanager darf "Unbekannte Apps installieren" brauchen).
2. Android 13 und neuer: **Einstellungen > Apps > Fortnite Rematch > ⋮ (oben rechts) > Eingeschränkte Einstellungen zulassen**. Ohne das lässt sich die Bedienungshilfe nicht einschalten.
3. **Einstellungen > Bedienungshilfen > Fortnite Rematch** einschalten.
4. Es erscheint ein kleines Panel über dem Bildschirm (am Statustext ziehen = verschieben).

## 3. Aufnehmen

Jede Aufnahme: Panel-Button tippen, Spiel innerhalb von 5 Sekunden auf den richtigen Bildschirm bringen, dann auf das Standbild tippen.

1. **+ Nächste Runde (Button):** Am Rundenende, wenn der "Nächste Runde"-Button sichtbar ist. Auf eine einfarbige Stelle des Buttons tippen, nicht auf den Text. Dieser Schritt wartet bis zu 30 Minuten.
2. **+ Bewegungs-Stick** (Anti-AFK, optional): Während einer laufenden Runde auf die Mitte des Bewegungs-Sticks tippen.
3. **+ Sprung-Button** (Anti-AFK, optional): Auf den Sprung-Button tippen.
4. **+ Weiterer Button:** Nur falls nach "Nächste Runde" noch ein Button bestätigt werden muss.

Dann **Start**. **Stop** beendet das Makro. Bei Zeitüberschreitung stoppt es und vibriert.

## Ablauf

- Wartet auf die Farbe des "Nächste Runde"-Buttons und tippt ihn an.
- Wartet danach, bis der Button verschwunden ist, damit er nicht doppelt getippt wird.
- Während des Wartens läuft alle 15-35 Sekunden eine zufällige Wischbewegung am Stick und ein Sprung (nur wenn aufgenommen).

## Tipps

- Das Panel darf nicht über den Buttons liegen, die getippt werden. Vor dem Start an eine freie Ecke ziehen.
- Während das Makro läuft, ist nur der Stop-Button sichtbar.
- Wenn nichts erkannt wird: Schritte löschen und neu aufnehmen, Helligkeit und Auflösung nicht mehr ändern.
- Wenn der Screenshot schwarz ist, blockiert die App Screenshots für Bedienungshilfen. Dann funktioniert die Erkennung nicht.

## Hinweis

Automatisierte Eingaben verstoßen gegen die Nutzungsbedingungen von Epic Games und werden teilweise erkannt. Auch zufällige Bewegungen schützen nicht sicher vor AFK-Kicks oder Sperren. Nutzung auf eigenes Risiko.
