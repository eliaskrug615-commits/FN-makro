package de.fnmacro

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Ein Schritt des Makros: Warte, bis die Farbe am Punkt (x, y) erscheint, dann tippe dorthin.
 * x und y sind Anteile der Bildschirmgröße (0..1), damit es unabhängig von der Auflösung bleibt.
 */
data class Step(
    val name: String,
    val x: Float,
    val y: Float,
    val color: Int,
    val timeoutSec: Int,
)

class StepStore(context: Context) {
    private val prefs = context.getSharedPreferences("steps", Context.MODE_PRIVATE)

    fun load(): MutableList<Step> {
        val out = mutableListOf<Step>()
        try {
            val arr = JSONArray(prefs.getString("steps", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Step(
                        name = o.getString("name"),
                        x = o.getDouble("x").toFloat(),
                        y = o.getDouble("y").toFloat(),
                        color = o.getInt("color"),
                        timeoutSec = o.getInt("timeout"),
                    )
                )
            }
        } catch (e: Exception) {
            // kaputte Daten ignorieren, mit leerer Liste starten
        }
        return out
    }

    fun save(steps: List<Step>) {
        val arr = JSONArray()
        for (s in steps) {
            arr.put(
                JSONObject()
                    .put("name", s.name)
                    .put("x", s.x.toDouble())
                    .put("y", s.y.toDouble())
                    .put("color", s.color)
                    .put("timeout", s.timeoutSec)
            )
        }
        prefs.edit().putString("steps", arr.toString()).apply()
    }

    /** Einzelner Punkt (z. B. Bewegungs-Stick oder Sprung-Button), als Anteil der Bildschirmgröße. */
    fun loadPoint(key: String): Pair<Float, Float>? {
        if (!prefs.contains(key + "_x")) return null
        return Pair(prefs.getFloat(key + "_x", 0f), prefs.getFloat(key + "_y", 0f))
    }

    fun savePoint(key: String, x: Float, y: Float) {
        prefs.edit().putFloat(key + "_x", x).putFloat(key + "_y", y).apply()
    }

    fun clearPoints() {
        prefs.edit().remove("move_x").remove("move_y").remove("jump_x").remove("jump_y").apply()
    }
}
